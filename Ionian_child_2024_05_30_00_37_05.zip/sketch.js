

function setup() {
  createCanvas(400, 600);
}

function draw() {
  background(220, 333, 260);

  // Calculate the x-coordinate for centering the rectangles
  let centerX = width / 2 - 150 / 2;

  // Draw rectangles centered horizontally
  rect(centerX, 200, 150, 50, 50);
  rect(centerX, 260, 150, 50, 50);
  rect(centerX, 320, 200, 50, 50);
  rect(centerX, 520, 270, 50, 50);
  strokeJoin(CENTER);
}
let reels = [0, 0, 0];
let isSpinning = false;
let result = [0, 0, 0];
let spinSpeed = 20;
let spinCounter = 0;
let maxSpinCount = 60;
let leverY = 75;
let leverPulled = false;

function setup() {
    createCanvas(windowWidth, windowHeight);
    textAlign(CENTER, CENTER);
    textSize(32);
}

function draw() {
    background(200);
    drawSlotMachine();
    drawLever();

    if (leverPulled) {
        pullLever();
    }

    if (isSpinning) {
        spinReels();
    } else {
        displayResult();
    }
}

function drawSlotMachine() {
    // Draw slot machine frame
    fill(255, 215, 0);
    rect(50, 50, 300, 200, 20);
    
    // Draw slot machine reels
    fill(255);
    for (let i = 0; i < 3; i++) {
        rect(75 + i * 100, 75, 75, 150);
        fill(0);
        text(reels[i], 75 + i * 100 + 37.5, 150);
        fill(255);
    }
    
    // Draw select button 
    fill(100);
    rect(150, 260, 100, 30);
    fill(255);
    textSize(20);
    text("select", 200, 275);
}

function drawLever() {
    // Draw lever base
    fill(150);
    rect(370, leverY, 20, 100);
    fill(255, 0, 0);
    ellipse(380, leverY + 100, 30, 30);
}

function mousePressed() {
    // Check if lever is pulled
    if (mouseX > 370 && mouseX < 390 && mouseY > leverY + 100 && mouseY < leverY + 130) {
        leverPulled = true;
    }
}

function pullLever() {
    if (leverY < 150) {
        leverY += 5;
    } else {
        leverPulled = false;
        leverY = 75;
        startSpinning();
    }
}

function startSpinning() {
    if (!isSpinning) {
        isSpinning = true;
        spinCounter = 0;
        reels = [0, 0, 0];
        result = [int(random(0, 10)), int(random(0, 10)), int(random(0, 10))];
    }
}

function spinReels() {
    if (spinCounter < maxSpinCount) {
        for (let i = 0; i < 3; i++) {
            reels[i] = int(random(0, 10));
        }
        spinCounter++;
    } else {
        isSpinning = false;
        reels = result;
    }
}

function displayResult() {
    fill(0);
    textSize(20);
    if (result[0] == result[1] && result[1] == result[2]) {
        text("Pull!", width / 2, 30);
    } else {
        text("is this it?", width / 2, 30);
    }
}